Application: Microsoft WordPad
Version: Backup from last Windows 11 Build - 23H2
Original Path: C:\Program Files\Windows NT\Accessories
Languages backup: en-GB, en-US, pl-PL